//AUTO RESPON VN
//JANGAN DI UBAH YEE

export const dmusic = [
"./temp/audio/dj 1.mp3",
"./temp/audio/dj 2.mp3",
"./temp/audio/dj 3.mp3",
"./temp/audio/dj 4.mp3",
"./temp/audio/dj 5.mp3",
]

export const maudio = [
""
]









