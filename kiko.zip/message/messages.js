//Toxic
export const bad = [
"anjing","Anjing","Memek","Asu","Asw","Bangsat","Tolol",
"Goblok","Gblk","Ajg","Kontol","mmk","Bangsat","Gblk","tolol",
"peler","Pler","ajg","asw","asu","Babi","kontol","ngentot","bngst"
]
//Toxic
export const dosa = [
"Bokep","bct","Bct","Ngentod","Snge","Sange","Blok","ngewe",
"Ngewe","Ngentd","vcs","Vcs","Coli","coli","colmek","Colmek",
"toket","Toket","oyo","Ah ah ah"
]
//Badword
export const badword = ["asu","Asu","asw","Asw","Ajg","ajg",
"Anjing","anjing","Bajingan","bajingan","Bjingan","bjingan",
"Babi","babi","Bacot","bacot","Bcot","bcot","Cacat","cacat",
"Jancok","jancok","Jncok","jncok","Kontol","kontol","Kntl",
"kntl","KONTOL","kirek","Kirek","Lonte","lonte","Lnte","lnte",
"Memek","memek","Mmek","mmek","Pler","pler","Silet","Silit",
"silit","Silet","Tai","tai","Taek","taek"
]

//Ucapan selamat malem
export const katamalem = [
"Selamat malam","selamat malam","Malam",
"malam","Malem","malem","oyasumi","Oyasumi",
"Oyasuminasai","oyasuminasai","Night","night",
"Good night","good night","Selamat tidur","selamat tidur"
]
//Ucapan terimakasih 
export const thanks = [
"hnk","hanks","akasih","ksh","ksih"
]
//Ucapan selamat siang
export const katasiang = [
"Selamat siang","selamat siang",
"Siang","siang","koniciwa","Koniciwa"
]
//Ucapan selamat sore
export const katasore = [
"Selamat sore","selamat sore","Sore","sore"
]
//Ucapan selamat pagi
export const ohayo = [
"pagi","Pagi","ohayo","Ohayo"
]
//Respon salam kenal
export const ken = [
"salken","Salken","slkn","Slkn","Slken"
]
//Ucapan hai
export const katahai = [
"Halo","halo","Hallo","hallo","Hai","hai","Moshi moshi",
"moshi moshi","Kirara","kirara","Woy","woy","woyy","weh","Weh"
]
//Respon orang gblok
export const salam = [
"P","p","p","Pp","pp","P","pP","PP"
]
//Respon panggilan bot
export const katabot = [
"bot","Bot","bott","Rangel","Halo","halo","Hallo","hallo","Hai","hai","Moshi moshi",
"moshi moshi","Kirara","kirara","Woy","woy","woyy","weh","Weh"
]
//Respon ara ara
export const katara = [
"ara","Ara","ara ara","Ara ara"
]
//Respon wibu
export const katakawai = [
"yare","yare yare","baka","Baka","gambare","Gambare"
]
//===========================================================//
//GANTI SETERAH LUH
//Ownerin
export const devoloper1 = "6283856571167"
//Gambar sewa

//pdf acak
export const pdf = [
    "application/pdf",
    "application/msword",
    "application/vnd.ms-excel",
    "application/vnd.ms-powerpoint",
    "application/zip",
    "application/x-rar-compressed",
    "application/x-tar",
    "application/x-7z-compressed",
    "application/epub+zip",
    "application/json"
]

