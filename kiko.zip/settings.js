
import { createRequire } from 'module'
import { fileURLToPath } from "url"
import fs from "fs"
const require = createRequire(import.meta.url)
const version = require("@whiskeysockets/baileys/package.json").version 
global.require = require
global.reloadFile = (file) => reloadFile(file)
global.language = "id"
global.nomerOwner ="6283856571167"
global.nomerOwner2 = "6283856571167"
global.runWith = "Panel"

global.ownerName = "Rico"
global.botName = "Kikoꪆᴮᵒᵗ" 
global.sessionName ="session"
global.setmenu ="location"
global.docType = "docx"
global.Qoted = "ftoko"
global.autoBio = false
global.baileysMd = true
global.antiSpam = true
global.fake = botName
global.Console = false
global.copyright = `© ${botName}`
global.baileysVersion = `Baileys ${version}`
global.fake1 ="Kikoꪆᴮᵒᵗ"
global.packName = "Kikoᴮᵒᵗ"
global.authorName = "Created By Rico"
global.replyType = "web"
global.setwelcome = "type11"
global.autoblockcmd = false
global.autoReport = true
global.autoLevel = true
global.autoSticker = false
global.gamewaktu = 60
global.limitCount = 30
global.Intervalmsg = 1000 //detik
global.session = 'session'
global.fileStackApi ="AVKHbeyXsT0G9IKI01qenz" //daftar di filestack
global.apiflash ='9b9e84dfc18746d4a19d3afe109e9ea4' //
global.gcounti = {
'prem' : 60,
'user' : 20
} 
// Apikey 
global.api = {
ehz: 'always ehz',
angel: 'zenzkey_af003aedbf', // Apikey Zahwazein
Lol: 'GataDios',
Botcahx: 'Admin',
}
global.syt = 'https://linktr.ee/kimhajin'
global.sgc = 'https://linktr.ee/kimhajin'
global.sig = 'https://linktr.ee/kimhajin'
global.ehanzUrl = 'https://telegra.ph/file/5f4cd39c620ea1951193a.jpg'
global.angelUrl = 'https://telegra.ph/file/a68b4b0de54e771e203e4.jpg'
global.fotoRandom = [
"https://cdn.btch.bz/file/b76b2a5a1efaddbc2fa22.jpg",
"https://cdn.btch.bz/file/18970a1a994a84a4454c6.jpg",
"https://cdn.btch.bz/file/18970a1a994a84a4454c6.jpg",
"https://telegra.ph/file/5f4cd39c620ea1951193a.jpg",
"https://telegra.ph/file/a68b4b0de54e771e203e4.jpg"

    ]



async function reloadFile(file) {
  file = (file).url || (file)
  let fileP = fileURLToPath(file)
  fs.watchFile(fileP, () => {
    fs.unwatchFile(fileP)
    console.log(`Update File "${fileP}"`)
    import(`${file}?update=${Date.now()}`)
  })
}

reloadFile(import.meta.url)





